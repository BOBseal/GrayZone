import React from 'react'

const Catalogue = () => {
  return (
    <div>Catalogue</div>
  )
}

export default Catalogue