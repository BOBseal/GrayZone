import React from 'react'

const Socials = () => {
  return (
    <div>Socials</div>
  )
}

export default Socials