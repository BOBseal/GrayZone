import React from 'react'

const WhyChooseUs = () => {
  return (
    <div>WhyChooseUs</div>
  )
}

export default WhyChooseUs